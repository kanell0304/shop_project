package com.shop.shop.service;

import com.shop.shop.domain.category.Category;
import com.shop.shop.dto.CategoryDTO;
import com.shop.shop.repository.CategoryItemRepository;
import com.shop.shop.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService{

    private final CategoryRepository categoryRepository;
    private final CategoryItemRepository categoryItemRepository;

    // 카테고리 등록
    @Override
    public CategoryDTO registerCategory(CategoryDTO categoryDTO) {
        Category category = new Category();
        category.changeCategoryName(categoryDTO.getCategoryName());

        // parentId가 존재하면 부모 카테고리 설정
        if (categoryDTO.getParentId() != null) {
            Category parentCategory = categoryRepository.findById(categoryDTO.getParentId()).orElseThrow(() -> new IllegalArgumentException("해당 parentId의 카테고리가 존재하지 않습니다."));
            category.changeParent(parentCategory);
            parentCategory.addChild(category); // 부모 카테고리에 자식 추가
        }

        // 저장 후 생성된 카테고리 엔티티를 DTO 로 변환하여 반환
        Category savedCategory = categoryRepository.save(category);
        return new CategoryDTO(savedCategory);
    }

    // 카테고리 삭제(하위 카테고리와 연결을 끊은 후)
    @Override
    public void deleteCategory(Long id) {
        List<Category> childCategories = categoryRepository.findAllChildCategories(id);
        if (childCategories != null) {
            for (Category child : childCategories) {
                child.changeParent(null);
            }
        }
        Category category = categoryRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("해당 ID를 가진 카테고리가 존재하지 않습니다."));
        categoryRepository.delete(category);
    }
}
