package com.shop.shop.domain.member;

public enum MemberRole {
    USER, MANAGER,ADMIN;
}
