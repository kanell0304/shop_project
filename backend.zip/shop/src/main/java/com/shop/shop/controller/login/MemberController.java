package com.shop.shop.controller.login;

import com.shop.shop.dto.MemberDTO;
import com.shop.shop.repository.MemberRepository;
import com.shop.shop.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@Log4j2
@RequestMapping("/api/member")
public class MemberController {

    private final MemberService memberService;
    private final MemberRepository memberRepository;
    private final ModelMapper modelMapper;

    @PostMapping("/register")
    public Map<String, String> registerMember(@RequestBody MemberDTO memberDTO) {
//        memberService.makeMember(
//                memberDTO.getEmail(),
//                memberDTO.getPassword(),
//                memberDTO.getMemberName(),
//                memberDTO.getPhoneNumber(),
//                memberDTO.getAddress().getZip_code(),
//                memberDTO.getAddress().getDefault_address(),
//                memberDTO.getAddress().getDetailed_address(),
//                memberDTO.isWtrSns()
//        );
        memberService.makeMember(memberDTO);
        return Map.of("result", "create");
    }

    // 모든 회원 조회
    @GetMapping // 기본 주소로 동작 -> /api/members
    public ResponseEntity<List<MemberDTO>> getAllMembers() {
        return ResponseEntity.ok(memberService.getAllMembers());
    }

//     특정 회원 조회 (ID 기준)
//     /api/members/login 접속하게 되면 아래의 메서드에 매핑이 될 수 있다. --> 에러
//     /api/members/id/3 == 이렇게 처리
    @GetMapping("/id/{id}")
    public ResponseEntity<MemberDTO> getMember(@PathVariable Long id) {
        return ResponseEntity.ok(memberService.getMemberById(id));
    }

    @GetMapping("/get/{email}")
    public ResponseEntity<MemberDTO> getMemberByEmail(@PathVariable String email) {
        return ResponseEntity.ok(memberService.getMemberByEmail(email));
    }

    // 회원 등록
//    @PostMapping
//    public ResponseEntity<MemberDTO> createMember(@RequestBody MemberDTO memberDTO) {
//        Long memberId = memberService.saveMember(memberDTO);
//        return ResponseEntity.ok(memberDTO);
//    }

    // 회원 삭제
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMember(@PathVariable Long id) {
        memberService.deleteMember(id);
        return ResponseEntity.noContent().build();
    }

    // 회원 정보 수정
    @PutMapping("/{id}")
    public ResponseEntity<MemberDTO> updateMember(@PathVariable Long id, @RequestBody MemberDTO memberDTO) {
        memberService.updateMember(memberDTO);
        return ResponseEntity.ok(memberService.getMemberById(id));
    }

    // 특정 이름으로 회원 검색
    @GetMapping("/search")
    public ResponseEntity<List<MemberDTO>> getMembersByName(@RequestParam String name) {
        return ResponseEntity.ok(memberService.getMembersByName(name));
    }

    // 회원 존재 여부 확인
    @GetMapping("/{id}/exists")
    public ResponseEntity<Boolean> existsById(@PathVariable Long id) {
        return ResponseEntity.ok(memberService.existsById(id));
    }

}
