package com.shop.shop.domain.member;

public enum MileageStatus {
    EARN,       // 마일리지 적립
    REDEEM;      // 마일리지 사용
}
