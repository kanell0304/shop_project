package com.shop.shop.domain.member;

public enum MemberShip {
    BRONZE,     // 브론즈
    SILVER,     // 실버
    GOLD,       // 골드
    PLATINUM,   // 플래티넘
    EMERALD,    // 에메랄드
    ADMIN;      // 관리자
}
